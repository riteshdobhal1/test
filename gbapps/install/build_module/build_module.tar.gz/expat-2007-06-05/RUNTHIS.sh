make clean
./configure '--prefix=/glassbeam/tools' 'CFLAGS=-O3' 'CPPFLAGS=-fPIC -I/glassbeam/tools/apache/include -I/glassbeam/tools/include/openssl -I/glassbeam/tools/include -I/usr/X11R6/include -I/usr/local/include -I/usr/include' 'LDFLAGS=-L/glassbeam/tools/apache/lib -L/glassbeam/tools/lib64 -L/glassbeam/tools/lib -L/usr/X11R6/lib64 -L/usr/local/lib64 -L/usr/lib64 -L/lib64 -L/usr/X11R6/lib -L/usr/local/lib -L/usr/lib -L/lib' '--with-pic=yes'
make
make test
make check
make install

