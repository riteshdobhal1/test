make clean
perl Makefile.PL PREFIX=/glassbeam/tools
make
make test
make check
make install

